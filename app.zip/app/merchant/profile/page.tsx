"use client";

import { useState, useEffect, useCallback } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { onAuthStateChanged, User, deleteUser } from "firebase/auth";
import {
  collection,
  doc,
  onSnapshot,
  getDoc,
  setDoc,
  deleteDoc,
  query,
  where,
  getDocs,
  serverTimestamp,
} from "firebase/firestore";
import { auth, db } from "@/lib/firebase";

interface VenueItem {
  id: string;
  name: string;
  slug: string;
}

function generateSlug(text: string): string {
  const greekToLatinMap: Record<string, string> = {
    α: "a", ά: "a", β: "v", γ: "g", δ: "d", ε: "e", έ: "e", ζ: "z", η: "i", ή: "i",
    θ: "th", ι: "i", ί: "i", ϊ: "i", ΐ: "i", κ: "k", λ: "l", μ: "m", ν: "n", ξ: "x",
    ο: "o", ό: "o", π: "p", ρ: "r", σ: "s", ς: "s", τ: "t", υ: "y", ύ: "y", ϋ: "y",
    ΰ: "y", φ: "f", χ: "ch", ψ: "ps", ω: "o", ώ: "o",
  };

  return text
    .toLowerCase()
    .split("")
    .map((char) => greekToLatinMap[char] || char)
    .join("")
    .replace(/[^a-z0-9\s-]/g, "")
    .trim()
    .replace(/\s+/g, "-")
    .replace(/-+/g, "-");
}

export default function MerchantProfilePage() {
  const router = useRouter();
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [authLoading, setAuthLoading] = useState(true);

  const [existingVenues, setExistingVenues] = useState<VenueItem[]>([]);
  const [selectedVenueId, setSelectedVenueId] = useState<string>("NEW");
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [geocoding, setGeocoding] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [message, setMessage] = useState<{ type: "success" | "error"; text: string } | null>(null);

  const [formData, setFormData] = useState({
    name: "",
    slug: "",
    category: "",
    area: "",
    address: "",
    phone: "",
    hours: "13:00 - 00:30 καθημερινά",
    description: "",
    image: "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=1200&q=80",
    lat: 37.9753,
    lng: 23.7361,
    highlights: "",
  });

  const loadVenueDetails = useCallback(async (venueId: string) => {
    if (venueId === "NEW") {
      setFormData({
        name: "",
        slug: "",
        category: "",
        area: "",
        address: "",
        phone: "",
        hours: "13:00 - 00:30 καθημερινά",
        description: "",
        image: "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=1200&q=80",
        lat: 37.9753,
        lng: 23.7361,
        highlights: "",
      });
      return;
    }

    setLoading(true);
    try {
      const docRef = doc(db, "venues", venueId);
      const docSnap = await getDoc(docRef);
      if (docSnap.exists()) {
        const data = docSnap.data();
        setFormData({
          name: data.name || "",
          slug: data.slug || docSnap.id,
          category: data.category || "",
          area: data.area || "",
          address: data.address || "",
          phone: data.phone || "",
          hours: data.hours || "13:00 - 00:30 καθημερινά",
          description: data.description || "",
          image: data.image || "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=1200&q=80",
          lat: data.lat ?? 37.9753,
          lng: data.lng ?? 23.7361,
          highlights: (data.highlights || []).join(", "),
        });
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, (user) => {
      if (!user) {
        router.push("/merchant/login");
      } else {
        setCurrentUser(user);
        setAuthLoading(false);
      }
    });
    return () => unsub();
  }, [router]);

  useEffect(() => {
    if (!currentUser) return;

    const q = query(
      collection(db, "venues"),
      where("ownerId", "==", currentUser.uid)
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const list: VenueItem[] = [];
      snapshot.forEach((d) => {
        const data = d.data();
        list.push({
          id: d.id,
          name: data.name || d.id,
          slug: data.slug || d.id,
        });
      });
      setExistingVenues(list);

      if (list.length > 0) {
        const savedId = typeof window !== "undefined" ? localStorage.getItem("happyseats_merchant_venueId") : null;
        const targetId = list.find((v) => v.id === savedId)?.id || list[0].id;
        setSelectedVenueId(targetId);
        loadVenueDetails(targetId);
      }
    });

    return () => unsubscribe();
  }, [currentUser, loadVenueDetails]);

  const handleSelectVenue = (venueId: string) => {
    setSelectedVenueId(venueId);
    setMessage(null);
    loadVenueDetails(venueId);
  };

  const handleNameChange = (newName: string) => {
    const autoSlug = generateSlug(newName);
    setFormData((prev) => ({
      ...prev,
      name: newName,
      slug: selectedVenueId === "NEW" ? autoSlug : prev.slug,
    }));
  };

  const handleGeocodeAddress = async () => {
    if (!formData.address.trim()) {
      alert("Παρακαλώ συμπληρώστε πρώτα τη διεύθυνση του καταστήματος.");
      return;
    }

    const queryStr = `${formData.address}, ${formData.area || "Αθήνα"}, Greece`.trim();
    setGeocoding(true);

    try {
      const res = await fetch(
        `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(queryStr)}`
      );
      const data = await res.json();
      if (data && data.length > 0) {
        const newLat = parseFloat(data[0].lat);
        const newLng = parseFloat(data[0].lon);
        setFormData((prev) => ({
          ...prev,
          lat: Number(newLat.toFixed(5)),
          lng: Number(newLng.toFixed(5)),
        }));
        alert(`Βρέθηκε η τοποθεσία!\nΠλάτος (Lat): ${newLat.toFixed(5)}, Μήκος (Lng): ${newLng.toFixed(5)}`);
      } else {
        alert("Δεν βρέθηκαν ακριβείς συντεταγμένες για τη διεύθυνση αυτή.");
      }
    } catch (err) {
      console.error(err);
      alert("Σφάλμα επικοινωνίας κατά την αναζήτηση της διεύθυνσης.");
    } finally {
      setGeocoding(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;

    setSaving(true);
    setMessage(null);

    let finalDocId = selectedVenueId;
    if (selectedVenueId === "NEW") {
      finalDocId = formData.slug.trim() || generateSlug(formData.name) || doc(collection(db, "venues")).id;
    }

    const highlightsArray = formData.highlights
      .split(",")
      .map((item) => item.trim())
      .filter((item) => item.length > 0);

    const latNum = parseFloat(String(formData.lat)) || 37.9753;
    const lngNum = parseFloat(String(formData.lng)) || 23.7361;

    try {
      await setDoc(
        doc(db, "venues", finalDocId),
        {
          ownerId: currentUser.uid,
          ownerEmail: currentUser.email,
          name: formData.name.trim(),
          slug: formData.slug.trim() || finalDocId,
          category: formData.category.trim(),
          area: formData.area.trim(),
          address: formData.address.trim(),
          phone: formData.phone.trim(),
          hours: formData.hours.trim(),
          description: formData.description.trim(),
          image: formData.image.trim(),
          lat: latNum,
          lng: lngNum,
          highlights: highlightsArray,
          updatedAt: serverTimestamp(),
        },
        { merge: true }
      );

      localStorage.setItem("happyseats_merchant_venueId", finalDocId);
      localStorage.setItem("happyseats_merchant_venueName", formData.name.trim());

      setMessage({ type: "success", text: "✓ Το προφίλ και η διεύθυνση αποθηκεύτηκαν επιτυχώς!" });
      setSelectedVenueId(finalDocId);
    } catch (err) {
      console.error(err);
      setMessage({ type: "error", text: "Παρουσιάστηκε σφάλμα κατά την αποθήκευση." });
    } finally {
      setSaving(false);
    }
  };

  const handleDeleteVenue = async () => {
    if (selectedVenueId === "NEW") return;
    const confirmName = prompt(
      `Είστε σίγουροι; Για επιβεβαίωση πληκτρολογήστε το όνομα του καταστήματος: "${formData.name}"`
    );
    if (confirmName !== formData.name) {
      alert("Το όνομα δεν ταίριαζε. Η διαγραφή ακυρώθηκε.");
      return;
    }

    setIsDeleting(true);
    try {
      const qSlots = query(collection(db, "slots"), where("venueName", "==", formData.name));
      const snapSlots = await getDocs(qSlots);
      for (const d of snapSlots.docs) {
        await deleteDoc(doc(db, "slots", d.id));
      }

      await deleteDoc(doc(db, "venues", selectedVenueId));

      alert("Το κατάστημα διαγράφηκε επιτυχώς.");
      localStorage.removeItem("happyseats_merchant_venueId");
      localStorage.removeItem("happyseats_merchant_venueName");
      router.push("/merchant");
    } catch (err) {
      console.error(err);
      alert("Σφάλμα κατά τη διαγραφή του καταστήματος.");
    } finally {
      setIsDeleting(false);
    }
  };

  const handleDeleteAccount = async () => {
    if (!currentUser) return;
    const confirmed = confirm(
      "ΠΡΟΣΟΧΗ: Αυτή η ενέργεια θα διαγράψει οριστικά τον λογαριασμό σας και όλα τα καταστήματα που σας ανήκουν. Θέλετε να συνεχίσετε;"
    );
    if (!confirmed) return;

    setIsDeleting(true);
    try {
      for (const v of existingVenues) {
        await deleteDoc(doc(db, "venues", v.id));
      }
      await deleteDoc(doc(db, "merchants", currentUser.uid));
      await deleteUser(currentUser);

      alert("Ο λογαριασμός σας διαγράφηκε οριστικά.");
      router.push("/");
    } catch (err: unknown) {
      console.error(err);
      const code = (err as { code?: string })?.code;
      if (code === "auth/requires-recent-login") {
        alert("Για λόγους ασφαλείας απαιτείται πρόσφατη σύνδεση. Παρακαλώ αποσυνδεθείτε, συνδεθείτε ξανά και δοκιμάστε πάλι.");
      } else {
        alert("Παρουσιάστηκε σφάλμα κατά τη διαγραφή του λογαριασμού.");
      }
    } finally {
      setIsDeleting(false);
    }
  };

  if (authLoading) {
    return (
      <div className="min-h-screen bg-surface text-text-muted flex items-center justify-center text-sm">
        Έλεγχος διαπιστευτηρίων...
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-surface text-text-main p-6 flex flex-col items-center">
      <header className="w-full max-w-2xl flex justify-between items-center pb-6 border-b border-border-theme mb-8">
        <div>
          <span className="text-xs font-bold uppercase tracking-widest text-brand-text">
            Merchant Studio
          </span>
          <h1 className="text-2xl font-black text-text-main">Διαχείριση Προφίλ & Μενού</h1>
          <p className="text-xs text-text-muted mt-1">
            Συνδεδεμένος ως: <strong className="text-text-main">{currentUser?.email}</strong>
          </p>
        </div>
        <Link
          href="/merchant"
          className="text-xs bg-card hover:bg-subtle px-3.5 py-2 rounded-xl transition text-text-main border border-border-theme shadow-sm"
        >
          ← Merchant Portal
        </Link>
      </header>

      <main className="w-full max-w-2xl bg-card border border-border-theme p-6 md:p-8 rounded-3xl shadow-sm space-y-6">
        <div className="bg-subtle p-4 rounded-2xl border border-border-theme space-y-2">
          <label className="block text-xs font-semibold text-text-muted uppercase tracking-wider">
            Επιλογή Καταστήματος προς Επεξεργασία
          </label>
          <select
            value={selectedVenueId}
            onChange={(e) => handleSelectVenue(e.target.value)}
            className="w-full bg-card border border-border-theme rounded-xl px-3.5 py-2.5 text-sm text-brand-text font-bold focus:outline-none focus:border-brand cursor-pointer shadow-sm"
          >
            {existingVenues.map((v) => (
              <option key={v.id} value={v.id}>
                📍 {v.name} ({v.slug})
              </option>
            ))}
            <option value="NEW">+ Δημιουργία Νέου Καταστήματος</option>
          </select>
        </div>

        {loading ? (
          <div className="text-center py-12 text-text-muted text-sm">Φόρτωση στοιχείων...</div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs text-text-muted mb-1">Όνομα Καταστήματος *</label>
                <input
                  required
                  type="text"
                  value={formData.name}
                  onChange={(e) => handleNameChange(e.target.value)}
                  placeholder="π.χ. Ταβέρνα ο Πέτρος"
                  className="w-full bg-subtle border border-border-theme rounded-xl px-3.5 py-2.5 text-sm text-text-main focus:outline-none focus:border-brand"
                />
              </div>

              <div>
                <label className="block text-xs text-text-muted mb-1">URL ID (Slug)</label>
                <input
                  type="text"
                  value={formData.slug}
                  onChange={(e) => setFormData({ ...formData, slug: e.target.value })}
                  placeholder="taverna-o-petros"
                  className="w-full bg-subtle border border-border-theme rounded-xl px-3.5 py-2.5 text-sm text-text-main font-mono focus:outline-none focus:border-brand"
                />
                <span className="text-[10px] text-text-muted mt-1 block">
                  URL: /venue/{formData.slug || "..."}
                </span>
              </div>

              <div>
                <label className="block text-xs text-text-muted mb-1">Κατηγορία / Κουζίνα *</label>
                <input
                  required
                  type="text"
                  value={formData.category}
                  onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                  placeholder="π.χ. Ελληνική Ταβέρνα, Ψησταριά"
                  className="w-full bg-subtle border border-border-theme rounded-xl px-3.5 py-2.5 text-sm text-text-main focus:outline-none focus:border-brand"
                />
              </div>

              <div>
                <label className="block text-xs text-text-muted mb-1">Περιοχή *</label>
                <input
                  required
                  type="text"
                  value={formData.area}
                  onChange={(e) => setFormData({ ...formData, area: e.target.value })}
                  placeholder="π.χ. Πλάκα, Κολωνάκι, Γλυφάδα"
                  className="w-full bg-subtle border border-border-theme rounded-xl px-3.5 py-2.5 text-sm text-text-main focus:outline-none focus:border-brand"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs text-text-muted mb-1">
                Ακριβής Διεύθυνση (Οδός, Αριθμός, ΤΚ) *
              </label>
              <input
                required
                type="text"
                value={formData.address}
                onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                placeholder="π.χ. Αδριανού 12, Αθήνα"
                className="w-full bg-subtle border border-border-theme rounded-xl px-3.5 py-2.5 text-sm text-text-main focus:outline-none focus:border-brand"
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs text-text-muted mb-1">Τηλέφωνο Επικοινωνίας *</label>
                <input
                  required
                  type="text"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  placeholder="+30 210 1234567"
                  className="w-full bg-subtle border border-border-theme rounded-xl px-3.5 py-2.5 text-sm text-text-main focus:outline-none focus:border-brand"
                />
              </div>

              <div>
                <label className="block text-xs text-text-muted mb-1">Ωράριο Λειτουργίας *</label>
                <input
                  required
                  type="text"
                  value={formData.hours}
                  onChange={(e) => setFormData({ ...formData, hours: e.target.value })}
                  placeholder="13:00 - 00:30 καθημερινά"
                  className="w-full bg-subtle border border-border-theme rounded-xl px-3.5 py-2.5 text-sm text-text-main focus:outline-none focus:border-brand"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs text-text-muted mb-1">URL Φωτογραφίας Καταστήματος *</label>
              <input
                required
                type="url"
                value={formData.image}
                onChange={(e) => setFormData({ ...formData, image: e.target.value })}
                placeholder="https://images.unsplash.com/..."
                className="w-full bg-subtle border border-border-theme rounded-xl px-3.5 py-2.5 text-sm text-text-main focus:outline-none focus:border-brand"
              />
            </div>

            <div>
              <label className="block text-xs text-text-muted mb-1">Περιγραφή Καταστήματος</label>
              <textarea
                rows={3}
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                placeholder="Λίγα λόγια για την ατμόσφαιρα, τη φιλοσοφία και το μενού..."
                className="w-full bg-subtle border border-border-theme rounded-xl px-3.5 py-2.5 text-sm text-text-main focus:outline-none focus:border-brand"
              />
            </div>

            <div>
              <label className="block text-xs text-text-muted mb-1">
                Highlights / Signature Πιάτα (χωρισμένα με κόμμα)
              </label>
              <input
                type="text"
                value={formData.highlights}
                onChange={(e) => setFormData({ ...formData, highlights: e.target.value })}
                placeholder="Αρνί στο φούρνο, Χωριάτικη σαλάτα, Τζατζίκι"
                className="w-full bg-subtle border border-border-theme rounded-xl px-3.5 py-2.5 text-sm text-text-main focus:outline-none focus:border-brand"
              />
            </div>

            {/* Συντεταγμένες και Αυτόματος Εντοπισμός */}
            <div className="bg-subtle p-4 rounded-2xl border border-border-theme space-y-3">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <span className="text-xs font-semibold text-brand-text block">
                  📍 Συντεταγμένες για τον Χάρτη Πελάτη
                </span>
                <button
                  type="button"
                  onClick={handleGeocodeAddress}
                  disabled={geocoding}
                  className="text-[11px] bg-card hover:bg-subtle text-brand-text font-bold px-3 py-1.5 rounded-lg border border-border-theme transition disabled:opacity-50 self-start sm:self-auto cursor-pointer shadow-sm"
                >
                  {geocoding ? "Αναζήτηση..." : "🔍 Αυτόματος Εντοπισμός από Διεύθυνση"}
                </button>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[11px] text-text-muted mb-1">Πλάτος (Lat)</label>
                  <input
                    type="number"
                    step="any"
                    value={formData.lat}
                    onChange={(e) => setFormData({ ...formData, lat: parseFloat(e.target.value) || 0 })}
                    className="w-full bg-card border border-border-theme rounded-xl px-3 py-2 text-xs text-text-main focus:outline-none focus:border-brand"
                  />
                </div>

                <div>
                  <label className="block text-[11px] text-text-muted mb-1">Μήκος (Lng)</label>
                  <input
                    type="number"
                    step="any"
                    value={formData.lng}
                    onChange={(e) => setFormData({ ...formData, lng: parseFloat(e.target.value) || 0 })}
                    className="w-full bg-card border border-border-theme rounded-xl px-3 py-2 text-xs text-text-main focus:outline-none focus:border-brand"
                  />
                </div>
              </div>
            </div>

            {message && (
              <div
                className={`p-3 rounded-xl text-xs font-semibold text-center ${
                  message.type === "success"
                    ? "bg-emerald-50 border border-emerald-200 text-emerald-800"
                    : "bg-red-50 border border-red-200 text-red-600"
                }`}
              >
                {message.text}
              </div>
            )}

            <button
              type="submit"
              disabled={saving}
              className="w-full py-3.5 bg-brand hover:bg-brand-hover text-white font-bold rounded-xl text-sm transition disabled:opacity-50 shadow-sm cursor-pointer"
            >
              {saving ? "Αποθήκευση..." : "Αποθήκευση Προφίλ & Μενού"}
            </button>
          </form>
        )}

        {/* Ζώνη Κινδύνου */}
        <section className="pt-6 border-t border-red-200 space-y-4">
          <div>
            <h3 className="text-sm font-bold text-red-600 flex items-center gap-1.5">
              <span>⚠️</span> Ζώνη Κινδύνου (Διαγραφή)
            </h3>
            <p className="text-xs text-text-muted mt-1">
              Ενέργειες με μόνιμη επίδραση στη βάση δεδομένων.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-3">
            {selectedVenueId !== "NEW" && (
              <button
                type="button"
                disabled={isDeleting}
                onClick={handleDeleteVenue}
                className="flex-1 py-3 bg-red-50 hover:bg-red-100 text-red-600 border border-red-200 rounded-xl text-xs font-bold transition disabled:opacity-50 cursor-pointer"
              >
                🗑️ Διαγραφή Επιλεγμένου Καταστήματος
              </button>
            )}

            <button
              type="button"
              disabled={isDeleting}
              onClick={handleDeleteAccount}
              className="flex-1 py-3 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-black transition disabled:opacity-50 shadow-sm cursor-pointer"
            >
              🚨 Οριστική Διαγραφή Λογαριασμού Συνεργάτη
            </button>
          </div>
        </section>
      </main>
    </div>
  );
}