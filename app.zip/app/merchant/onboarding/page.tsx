"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { onAuthStateChanged, User } from "firebase/auth";
import { collection, doc, setDoc, serverTimestamp } from "firebase/firestore";
import { auth, db } from "@/lib/firebase";

function generateSlug(text: string): string {
  const greekToLatinMap: Record<string, string> = {
    α: "a", ά: "a", β: "v", γ: "g", δ: "d", ε: "e", έ: "e", ζ: "z", η: "i", ή: "i",
    θ: "th", ι: "i", ί: "i", ϊ: "i", ΐ: "i", κ: "k", λ: "l", μ: "m", ν: "n", ξ: "x",
    ο: "o", ό: "o", π: "p", ρ: "r", σ: "s", ς: "s", τ: "t", υ: "y", ύ: "y", ϋ: "y",
    ΰ: "y", φ: "f", χ: "ch", ψ: "ps", ω: "o", ώ: "o",
  };

  return text
    .toLowerCase()
    .split("")
    .map((char) => greekToLatinMap[char] || char)
    .join("")
    .replace(/[^a-z0-9\s-]/g, "")
    .trim()
    .replace(/\s+/g, "-")
    .replace(/-+/g, "-");
}

export default function MerchantOnboardingPage() {
  const router = useRouter();
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(false);

  const [name, setName] = useState("");
  const [category, setCategory] = useState("");
  const [area, setArea] = useState("");
  const [address, setAddress] = useState("");
  const [phone, setPhone] = useState("");
  const [hours, setHours] = useState("13:00 - 00:30 καθημερινά");
  const [image, setImage] = useState(
    "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=1200&q=80"
  );
  const [description, setDescription] = useState("");

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, (user) => {
      if (!user) {
        router.push("/merchant/login");
      } else {
        setCurrentUser(user);
      }
    });
    return () => unsub();
  }, [router]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;
    setLoading(true);

    const slug = generateSlug(name) || doc(collection(db, "venues")).id;

    try {
      await setDoc(doc(db, "venues", slug), {
        ownerId: currentUser.uid,
        ownerEmail: currentUser.email,
        name: name.trim(),
        slug,
        category: category.trim(),
        area: area.trim(),
        address: address.trim(),
        phone: phone.trim(),
        hours: hours.trim(),
        description: description.trim(),
        image: image.trim(),
        lat: 37.9838,
        lng: 23.7275,
        status: "pending_approval",
        createdAt: serverTimestamp(),
      });

      localStorage.setItem("happyseats_merchant_venueId", slug);
      localStorage.setItem("happyseats_merchant_venueName", name.trim());

      alert("Το κατάστημα καταχωρήθηκε επιτυχώς!");
      router.push("/merchant");
    } catch (err) {
      console.error(err);
      alert("Σφάλμα κατά την καταχώρηση.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-surface text-text-main p-6 flex flex-col items-center">
      <header className="w-full max-w-xl flex justify-between items-center pb-6 border-b border-border-theme mb-8">
        <div>
          <span className="text-xs font-bold uppercase tracking-widest text-brand-text">
            HappySeats Partner
          </span>
          <h1 className="text-2xl font-black text-text-main">Καταχώριση Καταστήματος</h1>
        </div>
        <Link
          href="/merchant"
          className="text-xs bg-card hover:bg-subtle px-3.5 py-2 rounded-xl transition text-text-main border border-border-theme shadow-sm"
        >
          ← Dashboard
        </Link>
      </header>

      <main className="w-full max-w-xl bg-card border border-border-theme p-6 md:p-8 rounded-3xl shadow-sm space-y-5">
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-text-muted mb-1">
              Όνομα Καταστήματος *
            </label>
            <input
              required
              type="text"
              placeholder="π.χ. Ταβέρνα ο Πέτρος"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full bg-subtle border border-border-theme rounded-xl px-3.5 py-2.5 text-sm text-text-main focus:outline-none focus:border-brand"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-text-muted mb-1">
                Κατηγορία / Κουζίνα *
              </label>
              <input
                required
                type="text"
                placeholder="π.χ. Ελληνική, Ψησταριά"
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full bg-subtle border border-border-theme rounded-xl px-3.5 py-2.5 text-sm text-text-main focus:outline-none focus:border-brand"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-text-muted mb-1">
                Περιοχή *
              </label>
              <input
                required
                type="text"
                placeholder="π.χ. Πλάκα, Κολωνάκι"
                value={area}
                onChange={(e) => setArea(e.target.value)}
                className="w-full bg-subtle border border-border-theme rounded-xl px-3.5 py-2.5 text-sm text-text-main focus:outline-none focus:border-brand"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-text-muted mb-1">
              Ακριβής Διεύθυνση (Οδός & Αριθμός) *
            </label>
            <input
              required
              type="text"
              placeholder="π.χ. Αδριανού 12, Αθήνα"
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              className="w-full bg-subtle border border-border-theme rounded-xl px-3.5 py-2.5 text-sm text-text-main focus:outline-none focus:border-brand"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-text-muted mb-1">
                Τηλέφωνο Επικοινωνίας *
              </label>
              <input
                required
                type="text"
                placeholder="+30 210 1234567"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full bg-subtle border border-border-theme rounded-xl px-3.5 py-2.5 text-sm text-text-main focus:outline-none focus:border-brand"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-text-muted mb-1">
                Ωράριο Λειτουργίας *
              </label>
              <input
                required
                type="text"
                placeholder="13:00 - 00:30 καθημερινά"
                value={hours}
                onChange={(e) => setHours(e.target.value)}
                className="w-full bg-subtle border border-border-theme rounded-xl px-3.5 py-2.5 text-sm text-text-main focus:outline-none focus:border-brand"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-text-muted mb-1">
              URL Φωτογραφίας Καταστήματος *
            </label>
            <input
              required
              type="url"
              value={image}
              onChange={(e) => setImage(e.target.value)}
              className="w-full bg-subtle border border-border-theme rounded-xl px-3.5 py-2.5 text-sm text-text-main focus:outline-none focus:border-brand"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-text-muted mb-1">
              Σύντομη Περιγραφή
            </label>
            <textarea
              rows={3}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Λίγα λόγια για το μενού και την ατμόσφαιρα..."
              className="w-full bg-subtle border border-border-theme rounded-xl px-3.5 py-2.5 text-sm text-text-main focus:outline-none focus:border-brand"
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-3.5 bg-brand hover:bg-brand-hover text-white font-bold rounded-xl text-sm transition disabled:opacity-50 shadow-sm cursor-pointer"
          >
            {loading ? "Καταχώριση..." : "Ολοκλήρωση & Μετάβαση στο Portal"}
          </button>
        </form>
      </main>
    </div>
  );
}